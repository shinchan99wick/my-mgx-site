// Sample video data
const sampleVideos = [
    {
        id: 1,
        title: "Getting Started with Web Development",
        creator: "TechGuru",
        views: "125K views",
        date: "2 days ago",
        category: "tech",
        description: "Learn the basics of web development with HTML, CSS, and JavaScript. Perfect for beginners looking to start their coding journey.",
        thumbnail: "🎥"
    },
    {
        id: 2,
        title: "Morning Routine for Productivity",
        creator: "LifestyleBlogger",
        views: "89K views",
        date: "1 week ago",
        category: "lifestyle",
        description: "Discover how to create a morning routine that boosts your productivity and sets you up for success throughout the day.",
        thumbnail: "☀️"
    },
    {
        id: 3,
        title: "Advanced JavaScript Concepts",
        creator: "CodeMaster",
        views: "67K views",
        date: "3 days ago",
        category: "tech",
        description: "Deep dive into advanced JavaScript concepts including closures, prototypes, and asynchronous programming.",
        thumbnail: "💻"
    },
    {
        id: 4,
        title: "Photography Tips for Beginners",
        creator: "PhotoPro",
        views: "156K views",
        date: "5 days ago",
        category: "education",
        description: "Master the fundamentals of photography with these essential tips and techniques for capturing stunning images.",
        thumbnail: "📸"
    },
    {
        id: 5,
        title: "Latest Gaming Reviews",
        creator: "GameReviewer",
        views: "234K views",
        date: "1 day ago",
        category: "gaming",
        description: "Comprehensive reviews of the latest games, including gameplay analysis and recommendations.",
        thumbnail: "🎮"
    },
    {
        id: 6,
        title: "Music Production Basics",
        creator: "BeatMaker",
        views: "78K views",
        date: "4 days ago",
        category: "music",
        description: "Learn the fundamentals of music production, from recording to mixing and mastering your tracks.",
        thumbnail: "🎵"
    },
    {
        id: 7,
        title: "Healthy Cooking on a Budget",
        creator: "HealthyEats",
        views: "192K views",
        date: "6 days ago",
        category: "lifestyle",
        description: "Discover how to prepare nutritious and delicious meals without breaking the bank.",
        thumbnail: "🥗"
    },
    {
        id: 8,
        title: "React.js Complete Tutorial",
        creator: "WebDevPro",
        views: "345K views",
        date: "1 week ago",
        category: "tech",
        description: "Complete guide to React.js, covering components, state management, and modern development practices.",
        thumbnail: "⚛️"
    }
];

// DOM Elements
const videoGrid = document.getElementById('videoGrid');
const videoModal = document.getElementById('videoModal');
const videoPlayer = document.getElementById('videoPlayer');
const videoTitle = document.getElementById('videoTitle');
const videoViews = document.getElementById('videoViews');
const videoDate = document.getElementById('videoDate');
const videoDescription = document.getElementById('videoDescription');
const closeModal = document.getElementById('closeModal');
const searchInput = document.getElementById('searchInput');
const categoryBtns = document.querySelectorAll('.category-btn');

let currentVideos = [...sampleVideos];
let currentCategory = 'all';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('BlogStream initialized!');
    renderVideos(currentVideos);
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Category filter buttons
    categoryBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const category = e.target.dataset.category;
            filterByCategory(category);
            updateActiveCategory(e.target);
        });
    });

    // Search functionality
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        searchVideos(searchTerm);
    });

    // Search button
    document.querySelector('.search-btn').addEventListener('click', () => {
        const searchTerm = searchInput.value.toLowerCase();
        searchVideos(searchTerm);
    });

    // Modal close button
    closeModal.addEventListener('click', closeVideoModal);

    // Close modal when clicking outside
    videoModal.addEventListener('click', (e) => {
        if (e.target === videoModal) {
            closeVideoModal();
        }
    });

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && videoModal.style.display === 'block') {
            closeVideoModal();
        }
    });

    // Action buttons
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('like-btn')) {
            handleLike(e.target);
        } else if (e.target.classList.contains('share-btn')) {
            handleShare();
        } else if (e.target.classList.contains('save-btn')) {
            handleSave(e.target);
        }
    });
}

// Render videos in the grid
function renderVideos(videos) {
    if (videos.length === 0) {
        videoGrid.innerHTML = `
            <div class="no-results">
                <h3>No videos found</h3>
                <p>Try adjusting your search or browse different categories.</p>
            </div>
        `;
        return;
    }

    videoGrid.innerHTML = videos.map(video => `
        <div class="video-card" onclick="openVideoModal(${video.id})">
            <div class="video-thumbnail">
                <span class="play-icon">${video.thumbnail}</span>
            </div>
            <div class="video-info">
                <h3 class="video-title">${video.title}</h3>
                <div class="video-meta">
                    <span class="video-creator">${video.creator}</span>
                    <span class="video-views">${video.views}</span>
                </div>
                <div class="video-date">${video.date}</div>
            </div>
        </div>
    `).join('');
}

// Filter videos by category
function filterByCategory(category) {
    currentCategory = category;
    
    if (category === 'all') {
        currentVideos = [...sampleVideos];
    } else {
        currentVideos = sampleVideos.filter(video => video.category === category);
    }
    
    renderVideos(currentVideos);
}

// Update active category button
function updateActiveCategory(activeBtn) {
    categoryBtns.forEach(btn => btn.classList.remove('active'));
    activeBtn.classList.add('active');
}

// Search videos
function searchVideos(searchTerm) {
    if (!searchTerm.trim()) {
        filterByCategory(currentCategory);
        return;
    }

    const filteredVideos = sampleVideos.filter(video => 
        video.title.toLowerCase().includes(searchTerm) ||
        video.creator.toLowerCase().includes(searchTerm) ||
        video.description.toLowerCase().includes(searchTerm)
    );

    currentVideos = filteredVideos;
    renderVideos(currentVideos);
}

// Open video modal
function openVideoModal(videoId) {
    const video = sampleVideos.find(v => v.id === videoId);
    if (!video) return;

    videoTitle.textContent = video.title;
    videoViews.textContent = video.views;
    videoDate.textContent = video.date;
    videoDescription.textContent = video.description;

    // Set a placeholder video source (in a real app, this would be the actual video URL)
    videoPlayer.src = `https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4`;

    videoModal.style.display = 'block';
    document.body.style.overflow = 'hidden';

    // Track view (in a real app, this would update the database)
    console.log(`Playing video: ${video.title}`);
}

// Close video modal
function closeVideoModal() {
    videoModal.style.display = 'none';
    document.body.style.overflow = 'auto';
    videoPlayer.pause();
    videoPlayer.currentTime = 0;
}

// Handle like button
function handleLike(btn) {
    btn.classList.toggle('liked');
    if (btn.classList.contains('liked')) {
        btn.style.background = '#8B5CF6';
        btn.style.color = 'white';
        btn.textContent = '👍 Liked';
    } else {
        btn.style.background = 'transparent';
        btn.style.color = '#8B5CF6';
        btn.textContent = '👍 Like';
    }
}

// Handle share button
function handleShare() {
    if (navigator.share) {
        navigator.share({
            title: videoTitle.textContent,
            text: 'Check out this video on BlogStream!',
            url: window.location.href
        });
    } else {
        // Fallback for browsers that don't support Web Share API
        navigator.clipboard.writeText(window.location.href).then(() => {
            alert('Link copied to clipboard!');
        });
    }
}

// Handle save button
function handleSave(btn) {
    btn.classList.toggle('saved');
    if (btn.classList.contains('saved')) {
        btn.style.background = '#8B5CF6';
        btn.style.color = 'white';
        btn.textContent = '💾 Saved';
    } else {
        btn.style.background = 'transparent';
        btn.style.color = '#8B5CF6';
        btn.textContent = '💾 Save';
    }
}

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Add loading animation when switching categories
function showLoading() {
    videoGrid.innerHTML = '<div class="loading">Loading videos...</div>';
}

// Simulate network delay for better UX
function simulateLoading(callback, delay = 500) {
    showLoading();
    setTimeout(callback, delay);
}

// Enhanced category filtering with loading
categoryBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        const category = e.target.dataset.category;
        updateActiveCategory(e.target);
        
        simulateLoading(() => {
            filterByCategory(category);
        });
    });
});

// Add scroll-to-top functionality
window.addEventListener('scroll', () => {
    const scrollTop = document.documentElement.scrollTop;
    
    if (scrollTop > 300) {
        if (!document.querySelector('.scroll-to-top')) {
            const scrollBtn = document.createElement('button');
            scrollBtn.className = 'scroll-to-top';
            scrollBtn.innerHTML = '↑';
            scrollBtn.style.cssText = `
                position: fixed;
                bottom: 2rem;
                right: 2rem;
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background: #8B5CF6;
                color: white;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                z-index: 1000;
                transition: all 0.3s ease;
            `;
            
            scrollBtn.addEventListener('click', () => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
            
            document.body.appendChild(scrollBtn);
        }
    } else {
        const scrollBtn = document.querySelector('.scroll-to-top');
        if (scrollBtn) {
            scrollBtn.remove();
        }
    }
});

// Add keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Space bar to play/pause video
    if (e.code === 'Space' && videoModal.style.display === 'block') {
        e.preventDefault();
        if (videoPlayer.paused) {
            videoPlayer.play();
        } else {
            videoPlayer.pause();
        }
    }
    
    // Arrow keys for video seeking
    if (videoModal.style.display === 'block') {
        if (e.code === 'ArrowLeft') {
            videoPlayer.currentTime -= 10;
        } else if (e.code === 'ArrowRight') {
            videoPlayer.currentTime += 10;
        }
    }
});

// Initialize tooltips for better UX
function initTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', (e) => {
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = e.target.dataset.tooltip;
            tooltip.style.cssText = `
                position: absolute;
                background: #333;
                color: white;
                padding: 0.5rem;
                border-radius: 5px;
                font-size: 0.8rem;
                z-index: 1001;
                pointer-events: none;
            `;
            
            document.body.appendChild(tooltip);
            
            const rect = e.target.getBoundingClientRect();
            tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
            tooltip.style.left = rect.left + rect.width / 2 - tooltip.offsetWidth / 2 + 'px';
        });
        
        element.addEventListener('mouseleave', () => {
            const tooltip = document.querySelector('.tooltip');
            if (tooltip) {
                tooltip.remove();
            }
        });
    });
}

// Call tooltip initialization
initTooltips();